<?php

return array(
    'mail_user'=> 'romanrimskiy@gmail.com',
    'mail_password'=> 'qaz321wsx',
    'LIQPAY_PRIVATE_KEY'=>'yHvaJcudRn07m0Ef7NVrYZwlhdYIl5sjvFVF77Ag',
    'LIQPAY_PUBLIC_KEY'=>'i72350480191'
);