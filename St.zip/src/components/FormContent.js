import React from 'react';
import SectionForm from './SectionForm';


class FormContent extends React.Component{
    render(){

        return (
            <div>
                <SectionForm />
            </div>
        )
    }
}

export default FormContent;